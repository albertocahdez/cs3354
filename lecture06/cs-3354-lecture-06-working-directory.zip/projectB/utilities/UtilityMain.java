package utilities;

import utilities.CylinderType;

public class UtilityMain {
	public static void main(String[] args) {
		CylinderType cylinder = new CylinderType();
	}
}