package miscellaneous;

import utilities.CircleType;

public class MyMain {
	public static void main(String[] args) {
		CircleType circle = new CircleType();
		System.out.println("Radius: " + circle.getRadius());
		System.out.println("Area: " + circle.getArea());
	}
}
