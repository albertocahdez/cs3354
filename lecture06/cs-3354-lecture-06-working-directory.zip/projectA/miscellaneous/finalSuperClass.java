package projectA.miscellaneous;

public final class finalSuperClass {
	public final int myConstantValue = 200;

	public final void myFinalMethod() {
		System.out.println("This is a final method.");
	}
}
