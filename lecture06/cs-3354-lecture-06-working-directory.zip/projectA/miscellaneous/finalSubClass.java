package projectA.miscellaneous;

public class finalSubClass {

}
