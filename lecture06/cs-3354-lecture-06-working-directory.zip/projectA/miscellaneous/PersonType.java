package projectA.miscellaneous;

public class PersonType {

}
